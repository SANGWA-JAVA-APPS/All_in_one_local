/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alli_in_one_local;

import com.cd.reporting.Pdf_viewer;
import com.cg.dal.Inserts;
import com.cg.dal.Multi_records;
import com.cg.dal.Pdf_data;
import com.cg.dal.User_list;
import com.cg.model.PeopleBean;
import com.cg.model.PeopleList;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.event.WindowStateListener;
import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Properties;
import java.util.Scanner;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.text.Text;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.Border;
import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;

/**
 *
 * @author SANGWA
 */
public class Users extends JFrame {

    
    private final JPanel pn = new JPanel();
    private final JPanel status_pane = new JPanel();
    private final JPanel btn_pane = new JPanel();
     
    private final JButton btn_save = new JButton("Save User");
    private final JButton btn_view = new JButton("View & search");
    private final JButton btn_update = new JButton("Update");
    private final JButton btn_delete = new JButton("Delete User");
    private final JButton btn_print = new JButton("Print PDF");
    JTextField txt1 = new Global().txt, txt2 = new Global().txt;
    static JTable tb = new JTable();
    JLabel lbl_status = new JLabel();
    Multi_records data_list = new Multi_records();
    Inserts data_new = new Inserts();
    Box bx = Box.createVerticalBox();
    private int rows = 1;
    //fields
    
    public Users(String title, int w, int h) throws SQLException {

        //Initialize the form
        new Global().Form_init(this, title, w, h, btn_save);
        new Global().SetCenter(this);
        this.setFocusableWindowState(true);

        setup_default_views();
        setup_Form();
        setup_Grid();
        setup_Events();
        pn.add(bx);
        pn.setBackground(Color.white);
        add(bx);

    }

    final void setup_default_views() {
        new Global().setup_stauts_layout(status_pane, lbl_status, "USER REGISTRATION FORM");
        new Global().setup_buttons_layout(btn_pane, btn_save, btn_print, btn_update, btn_delete, btn_view);
        bx.add(status_pane);
    }

    final void setup_Form() {
        Box form_pane = Box.createVerticalBox();
        form_pane.add(new Global().input_layout("Name", txt1));
        form_pane.add(new Global().input_layout("Surname", txt2));
        form_pane.add(new Global().input_date_layout("Date 1", user_date_datePane.instance));
        form_pane.add(new Global().input_date_layout("Date 2", user2_date_datePane.instance));
        new Global().Titled_border(form_pane, bx, "Add user Details");
        bx.add(btn_pane);
    }

    final void setup_Grid() throws SQLException {
        data_list.load_account(tb, 5);
        bx.add(new JScrollPane(tb));

    }

    final void setup_Events() {
        btn_save.addActionListener((ActionEvent e) -> {
            Format formatter = new SimpleDateFormat("yyyy-MM-dd ");
            String d = formatter.format(user_date_datePane.instance.dl.cal.getTime());
            
            
            if (!"".equals(txt1.getText())) {
                data_new.new_account_type(txt1.getText());
                lbl_status.setText("Data saved successfully");
                txt1.setText("");
                txt2.setText("");
                try {
                    data_list.load_account(tb, rows);
                    rows += 1;
                } catch (SQLException ex) {
                    Logger.getLogger(Users.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {

            }

        });
        btn_view.addActionListener((ActionEvent e) -> {
            try {
                new Global().List_display("Users List");
            } catch (SQLException ex) {
                Logger.getLogger(Users.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

        btn_update.addActionListener((ActionEvent e) -> {
            if (!"".equals(txt1.getText())) {

                lbl_status.setText("Data Update successfully");
            }
        });
        btn_print.addActionListener((ActionEvent e) -> {
            try {
                new Pdf_viewer("Account_type", new Pdf_data().account_type());
            } catch (SQLException ex) {
                Logger.getLogger(Users.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
    }

    public static class user_date_datePane extends JPanel {

        public static user_date_datePane instance;

        static {
            instance = new user_date_datePane();
        }
        Global.service_date_dateLabel dl = new Global.service_date_dateLabel();

        private user_date_datePane() {
            new Global().j(this, dl);
        }

        public static user_date_datePane getInstance() {
            return instance;
        }
    }

    public static class user2_date_datePane extends JPanel {

        public static user2_date_datePane instance;

        static {
            instance = new user2_date_datePane();
        }
        Global.service_date_dateLabel dl = new Global.service_date_dateLabel();

        private user2_date_datePane() {
            new Global().j(this, dl);
        }

        public static user2_date_datePane getInstance() {
            return instance;
        }
    }

}
