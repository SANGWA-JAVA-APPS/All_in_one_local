/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alli_in_one_local;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author SANGWA
 */
public class Products extends JFrame {

    Box bx = Box.createVerticalBox();
    Container contP;
    JButton btn_save = new JButton("Save User");

    public Products(String title, int w, int h) {
        new Global().Form_init(this, title, w, h, new JButton("Save"));
        new Global().SetCenter(this);

        contP = this.getContentPane();
        JPanel pn = new JPanel();
        JTextField txt1 = new JTextField(25), txt2 = new JTextField(25);

        bx.add(new Global().input_layout("Product name", txt1));
        bx.add(new Global().input_layout("Cost", txt2));
        bx.add(new Global().input_date_layout("Date of birth", product_date_datePane.instance));
        bx.add(btn_save);
        pn.add(bx);

        contP.add(pn, BorderLayout.CENTER);

//        System.out.println("Components: "+ contP.);
        btn_save.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("The value 1: " + txt1.getText());

            }
        });

    }

    public static class product_date_datePane extends JPanel {

        public static product_date_datePane instance;

        static {
            instance = new product_date_datePane();
        }
        Global.service_date_dateLabel dl = new Global.service_date_dateLabel();

        private product_date_datePane() {
            new Global().j(this, dl);
        }

        public static product_date_datePane getInstance() {
            return instance;
        }
    }
}
