/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alli_in_one_local;

import com.cg.dal.Multi_records;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;
import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.SwingConstants;

/**
 *
 * @author SANGWA
 */
public class Homepage extends JFrame {

    JMenuBar bar = new JMenuBar();
    JTable tb = new JTable();
    Multi_records data_list = new Multi_records();

    public Homepage() {

        new MenuEvents(this, "Users", bar, "Users", "New user", 570, 520);
        new MenuEvents(this, "Products", bar, "Products", "New product", 500, 300);
        new MenuEvents(this, "Sales", bar, "Sales", "New sale", 500, 300);
        setJMenuBar(bar);
        setExtendedState(this.MAXIMIZED_BOTH);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JToolBar bar = new JToolBar(SwingConstants.VERTICAL);

        try {
            tb.setSize(900, 50);
            data_list.load_account(tb);
        } catch (SQLException ex) {
            Logger.getLogger(Homepage.class.getName()).log(Level.SEVERE, null, ex);
        }

        Box parent_parent = Box.createVerticalBox();

        JPanel pane_status = new JPanel();
        JLabel lbl_status = new JLabel("Welcome to Coffe Shop & Bar");
        Font current = new Font("Century gothic", Font.BOLD, 30);
        lbl_status.setFont(current);
        lbl_status.setForeground(new Color(250, 250, 200));
        pane_status.setLayout(new GridLayout(1, 2));
        pane_status.add(lbl_status);
        pane_status.setBackground(new Color(20, 200, 200));
        
        JPanel pane_status2 = new JPanel();
        pane_status2.setLayout(new GridLayout(1, 2));

        Font current2 = new Font("Century gothic", Font.BOLD, 15);
        JLabel lbl2 = new JLabel("clock");
        JLabel lbl22 = new JLabel("Logged in user");
        lbl2.setFont(current2);
        lbl22.setFont(current2);
        pane_status2.add(lbl2);
        pane_status2.add(lbl22);
        pane_status2.setBackground(new Color(20, 200, 200));

        pane_status.add(pane_status2);

        JPanel pane_search_controls = new JPanel();
        FlowLayout fl_search = new FlowLayout(FlowLayout.LEFT, 2, 4);
        pane_search_controls.setLayout(fl_search);
        Dimension objDimension = Toolkit.getDefaultToolkit().getScreenSize();
        pane_search_controls.setSize(objDimension.width - 40, 50);
        JLabel lbl_search_txt = new JLabel("Enter the criteria");
        JTextField txt_search = new JTextField(40);
        JTextField txt_date1 = new JTextField(20);
        JTextField txt_date2 = new JTextField(20);
        txt_date1.setText("Date 1");
        txt_date2.setText("Date 2");
        JButton btn_search = new JButton("Search");

        pane_search_controls.add(lbl_search_txt);
        pane_search_controls.add(txt_search);
        pane_search_controls.add(txt_date1);
        pane_search_controls.add(txt_date2);
        pane_search_controls.add(btn_search);
        pane_search_controls.setBackground(Color.white);

        JPanel pane_grid_status = new JPanel();
        JPanel pane_buttons = new JPanel();
        pane_buttons.setBackground(new Color(20, 200, 200));
        JButton btn_users = new JButton("Users");
        JButton btn_print = new JButton("Print/Export ");
        JButton btn_logout = new JButton("Logout");
        btn_print.setMargin(new Insets(5, 5, 5, 5));
        btn_users.setMargin(new Insets(5, 5, 5, 5));
        btn_logout.setMargin(new Insets(5, 5, 5, 5));

        FlowLayout fl_buttons = new FlowLayout(FlowLayout.RIGHT, 40, 4);
        pane_buttons.setLayout(fl_buttons);
        pane_buttons.add(btn_users);
        pane_buttons.add(btn_logout);
        pane_buttons.add(btn_print);

        parent_parent.add(pane_status);
        parent_parent.add(pane_search_controls);
        parent_parent.add(new JScrollPane(tb));
        parent_parent.add(pane_buttons);
        Color clr = new Color(20, 200, 200);
        parent_parent.setBackground(clr);
        this.setFont(new Font("Century gothic", Font.PLAIN, 13));
        this.setMinimumSize(new Dimension(600, 600));
        add(parent_parent);
        this.addWindowFocusListener(new WindowFocusListener() {
            @Override
            public void windowGainedFocus(WindowEvent e) {

            }

            @Override
            public void windowLostFocus(WindowEvent e) {
                Global.home_minimized = true;

            }
        });

        //get the timer and publish
    }

    class Small extends Thread {

        @Override
        public void run() {
            System.out.println("Called small");
            client_awakened();

        }
    }

    public static void main(String[] args) {
        new Homepage();

    }

    private static void server_alert() {
        try {
            int n = 30, temp = 0;

            ServerSocket socket = new ServerSocket(1234);
            Socket ss = socket.accept();

            Scanner sc = new Scanner(ss.getInputStream());

            temp = sc.nextInt() * 3;

            PrintStream pr = new PrintStream(ss.getOutputStream());
            pr.print(n);

        } catch (IOException ex) {
            Logger.getLogger(Homepage.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void client_awakened() {
        try {
            int n = 30, temp = 0;

            Socket socket = new Socket("127.0.0.1", 1234);
            Scanner sc1 = new Scanner(socket.getInputStream());
            PrintStream pr = new PrintStream(socket.getOutputStream());

            pr.print(n);
            temp = sc1.nextInt();

            System.out.println(temp);
        } catch (IOException ex) {
            Logger.getLogger(Homepage.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
