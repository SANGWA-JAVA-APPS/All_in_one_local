/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alli_in_one_local;

 
import com.cg.dal.User_list;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;
import java.awt.event.WindowListener;
import java.sql.SQLException;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;

/**
 *
 * @author SANGWA
 */
public class Global {

    static ArrayList<String> open_forms = new ArrayList<>();
    static boolean home_minimized = false;
    public static Font current = new Font("Century gothic", Font.PLAIN, 13);
    public static String logged_in_user = "Sangwa Emmanuel";

    public JTextField txt = new JTextField(35);
    public JLabel lbl = new JLabel();

    public void List_init(JFrame frm, String title, int w, int h) {
        frm.setTitle(title);
        frm.setSize(w, h);
        Dimension objDimension = Toolkit.getDefaultToolkit().getScreenSize();
        int iCoordX = (objDimension.width - frm.getWidth()) / 2;
        int iCoordY = 50;
        frm.setLocation(iCoordX, iCoordY);

        JPanel parent_panel = new JPanel();
        frm.setAlwaysOnTop(true);
        frm.addWindowFocusListener(new WindowFocusListener() {
            @Override
            public void windowGainedFocus(WindowEvent e) {

            }

            @Override
            public void windowLostFocus(WindowEvent e) {
                Global.open_forms.remove(title);
                frm.setVisible(false);
                System.out.println("List unfocused");
            }
        });

    }

    public JPanel search_layout(String search_title, FlowLayout search_layout) {
        JPanel search_pane = new JPanel();
        search_pane.setLayout(search_layout);
        search_pane.add(new JLabel(search_title));
        search_pane.add(new JTextField(40));
        search_pane.add(new JButton("Search: "));
        return search_pane;
    }

    public void List_display(String form) throws SQLException {
        if (!Global.open_forms.contains(form)) {
            Global.open_forms.add(form);
            if ("Users List".equals(form)) {
                new User_list().setVisible(true);
            }
        }

    }

    public void Form_init(JFrame frm, String title, int w, int h, JButton btn) {
        frm.setTitle(title);
        frm.setSize(w, h);
        frm.addWindowFocusListener(new WindowFocusListener() {
            @Override
            public void windowGainedFocus(WindowEvent e) {

            }

            @Override
            public void windowLostFocus(WindowEvent e) {
                if (Global.home_minimized) {

                    Global.open_forms.remove(frm.getTitle());
                    frm.setVisible(false);
                }
            }
        });
        frm.getRootPane().setDefaultButton(btn);
    }

    public void SetCenter(javax.swing.JFrame objFrame) {
        Dimension objDimension = Toolkit.getDefaultToolkit().getScreenSize();
        int iCoordX = (objDimension.width - objFrame.getWidth()) / 2;
        int iCoordY = 50;
        objFrame.setLocation(iCoordX, iCoordY);
        objFrame.setAlwaysOnTop(true);
        objFrame.setMinimumSize(new Dimension(600, 300));
        objFrame.addWindowFocusListener(new WindowFocusListener() {
            @Override
            public void windowGainedFocus(WindowEvent e) {
//                System.out.println("maximized!");
            }

            @Override
            public void windowLostFocus(WindowEvent e) {
//                System.out.println("minimized!");
            }
        });
        objFrame.addWindowListener(new WindowListener() {
            @Override
            public void windowOpened(WindowEvent e) {

            }

            @Override
            public void windowClosing(WindowEvent e) {
                Global.open_forms.remove(objFrame.getTitle());

            }

            @Override
            public void windowClosed(WindowEvent e) {

            }

            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }
        });
        SwingUtilities.updateComponentTreeUI(objFrame);
    }

    public JPanel input_layout(String lbl_txt, JTextField txt) {
        txt.setMargin(new Insets(2, 2, 2, 2));
        JLabel lbl = new JLabel(lbl_txt + "  :");
        lbl.setFont(current);
        txt.setFont(current);
        FlowLayout username_layout = new FlowLayout(FlowLayout.RIGHT, 10, 5);
        JPanel pane = new JPanel();
        pane.setLayout(username_layout);
        pane.setBackground(Color.white);
        pane.add(lbl);
        pane.add(txt);
        return pane;
    }

    public JPanel input_date_layout(String lbl_txt, JPanel txt) {
        JLabel lbl = new JLabel(lbl_txt + "  :");
        lbl.setFont(current);
        txt.setFont(current);
        FlowLayout username_layout = new FlowLayout(FlowLayout.RIGHT, 10, 5);
        JPanel pane = new JPanel();
        pane.setLayout(username_layout);
        pane.setBackground(Color.white);
        pane.add(lbl);
        pane.add(txt);
        return pane;
    }

    public void setup_stauts_layout(JPanel status_pane, JLabel lbl, String title) {
        FlowLayout lble_layout = new FlowLayout(FlowLayout.CENTER, 10, 10);
       lbl.setText(title);
        Color clr = new Color(20, 200, 200);
        status_pane.setBackground(clr);
        status_pane.add(lbl);
        status_pane.setLayout(lble_layout);
    }

    public void Titled_border(Box form_pane, Box bx, String title) {
        JPanel bordered_pane = new JPanel();
        bordered_pane.setBackground(Color.white);
        bordered_pane.setBorder(new Global().getBorder(title));
        bordered_pane.add(form_pane);

        JPanel empty_height = new JPanel();
        empty_height.add(new JLabel("."));
        empty_height.setBackground(Color.white);
        empty_height.setSize(100, 200);
        bx.add(empty_height);
        bx.add(bordered_pane);
    }

    public void setup_buttons_layout(JPanel pane, JButton save, JButton print, JButton update, JButton delete, JButton view) {
        Color clr = new Color(20, 200, 200);
        int padding = 3;
        Border bevelLoweredBorder = BorderFactory.createLineBorder(Color.green, 3);
        Font current = new Font("Century gothic", Font.PLAIN, 12);
        delete.setBackground(Color.red);
        delete.setMargin(new Insets(padding, padding, padding, padding));
        delete.setForeground(Color.white);
        print.setMargin(new Insets(padding, padding, padding, padding));
        update.setMargin(new Insets(padding, padding, padding, padding));
        view.setMargin(new Insets(padding, padding, padding, padding));
        save.setMargin(new Insets(padding, padding, padding, padding));

        save.setFont(current);
        save.setBackground(clr);
        pane.add(view);
        pane.setBackground(Color.white);
        pane.add(delete);
        pane.add(update);
        pane.add(print);
        pane.add(save);
        pane.setLayout(new FlowLayout(FlowLayout.RIGHT, 10, 30));
    }

    public Border getBorder(String title) {
        Border etched = BorderFactory.createEtchedBorder(EtchedBorder.LOWERED);
        Border titledBorder = BorderFactory.createTitledBorder(etched, title);
        return titledBorder;
    }

    public String TodayDate() {
        Date date = new Date();
        Format formatter = new SimpleDateFormat("yyyy-MM-dd ");
        String d = formatter.format(date);
        return d;
    }

    //<editor-fold defaultstate="collapsed" desc="------------Date Picker ---------------">
  public  void j(JPanel datejp, Object o){
            UtilDateModel model = new UtilDateModel();
            Properties p = new Properties();
            p.put("text.today", "Today");
            p.put("text.month", "Month");
            p.put("text.year", "Year");
            JDatePanelImpl datePanel = new JDatePanelImpl(model, p);
            JDatePickerImpl datePicker = new JDatePickerImpl(datePanel,(JFormattedTextField.AbstractFormatter) o);
            
            datejp.setLayout(new GridBagLayout());
            datejp.setSize(400, 50);
            datejp.add(datePicker);
        } 
    public static class service_date_dateLabel extends JFormattedTextField.AbstractFormatter {

        public static Calendar cal = null;
        private String datePattern = "yyyy-MM-dd";
        private SimpleDateFormat dateFormatter = new SimpleDateFormat(datePattern);

        @Override
        public Object stringToValue(String text) throws ParseException {
            return dateFormatter.parseObject(text);
        }

        @Override
        public String valueToString(Object value) throws ParseException {
            if (value != null) {

                cal = (Calendar) value;
                return dateFormatter.format(cal.getTime());
              
            }

            return "";
        }

    }

//</editor-fold>
}
