/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alli_in_one_local;

import com.cg.dal.Db_con;
import com.cg.forms.Login;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;
import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 *
 * @author SANGWA
 */
public class Alli_in_one_local {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | UnsupportedLookAndFeelException e) {
        }

        //Create dnvironment

        //Show Login

        new Login().setVisible(true);

    }

    private static void server_alert() {
        try {
            int temp = 0;

            ServerSocket socket = new ServerSocket(1234);
            Socket ss = socket.accept();
            Scanner sc = new Scanner(ss.getInputStream());
            temp = sc.nextInt() * 3;

            PrintStream pr = new PrintStream(ss.getOutputStream());
            pr.print(temp);
            System.out.println("Accepted: " + temp);

        } catch (IOException ex) {
            Logger.getLogger(Homepage.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
    }

    static class Big extends Thread {

        @Override
        public void run() {
            System.out.println("Thread started");
            server_alert();
        }
    }

}
