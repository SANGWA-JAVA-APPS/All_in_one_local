/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alli_in_one_local;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

/**
 *
 * @author SANGWA
 */
public class MenuEvents {

    
    public MenuEvents(JFrame frm, String form, JMenuBar bar, String menu, String menu_item, int w, int h) {

         
        
        JMenu jmenu = new JMenu(menu);
        JMenuItem jmenu_item = new JMenuItem(menu_item);
        jmenu.add(jmenu_item);
        bar.add(jmenu);
        jmenu_item.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!Global.open_forms.contains(form)) {
                    Global.open_forms.add(form);
                    if ("Users".equals(form)) {
                        try {
                            new Users(form, w, h).setVisible(true);
                            
                        } catch (SQLException ex) {
                            Logger.getLogger(MenuEvents.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    } else if ("Products".equals(form)) {
                        new Products(form, w, h).setVisible(true);
                    }

                } else {

                }
            }
        });

    }

}
