/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cd;

import com.sun.swing.internal.plaf.basic.resources.basic_pt_BR;
import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author SANGWA
 */
public class connection {

    public static void main(String[] args) throws Exception {

        String bseic_path = System.getProperty("user.home");
        String custm_path="C:\\Apache\\webapps\\Jpa_mysql";
        String cmd="mvn clean";
        
        
        
        
        
        
        
        
        
        
        
        ProcessBuilder builder = new ProcessBuilder(
                "cmd.exe", "/c", "cd \"" + bseic_path + "\" && "+ cmd);
        builder.redirectErrorStream(true);
        Process p = builder.start();
        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line;
        while (true) {
            line = r.readLine();

            if (line == null) {
                break;
            }
            if (line.contains("payara")) {
                System.out.println("------There is a folder of payara: " + line);
            }
            System.out.println(line);
        }
    }
}
