package com.cd.reporting;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

public class Pdf_viewer {

    static String user = System.getProperty("user.home");

    public Pdf_viewer(String report_name, ArrayList data) {
        compile(report_name);
        get_preview(report_name,data);
//        get_export_pdf(report_name);

    }

    public static void main(String[] args) {
//        new Pdf_viewer("my_report");

    }

    private static void get_export_pdf(String report_name,ArrayList data) {

        String sourceFileName = user + "/Desktop/"+report_name+".jasper";
        String printFileName = null;
        JRBeanCollectionDataSource beanColDataSource = new JRBeanCollectionDataSource(data);
        Map parameters = new HashMap();
        try {
            printFileName = JasperFillManager.fillReportToFile(sourceFileName, parameters, beanColDataSource);
            if (printFileName != null) {
                JasperExportManager.exportReportToPdfFile(printFileName, user + "/Desktop/" + report_name + ".pdf");
            }
        } catch (JRException e) {
            e.printStackTrace();
        }
    }

    private void compile(String report_name) {

        String sourceFileName = user + "/Desktop/"+report_name+".jrxml";
        System.out.println("Compiling Report Design ...");

        try {
            /**
             * Compile the report to a file name same as the JRXML file name
             */
            JasperCompileManager.compileReportToFile(sourceFileName);

        } catch (JRException e) {
            e.printStackTrace();
        }

    }

    private void get_preview(String report_name,ArrayList data) {
        //Preview the file
        try {
            JRBeanCollectionDataSource Account_type = new JRBeanCollectionDataSource(data);
            JasperDesign jasperDesign = JRXmlLoader.load(user + "/Desktop/"+report_name+".jrxml");
            JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, null, Account_type);
            JasperViewer.viewReport(jasperPrint, false);

        } catch (JRException ec) {
        }
    }

}
