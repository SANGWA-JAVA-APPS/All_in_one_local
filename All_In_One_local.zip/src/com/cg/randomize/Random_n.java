/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cg.randomize;

import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author SANGWA
 */
public class Random_n {

    int get_random_code() {
        Double n = 5.0;

        Double max = 90000.0, min = 10000.0;
//
//        while (true) {
//
//            //Change to
//            try {
//                Thread.sleep(1500);
//                System.out.println("\n\nuser code: " + user_code(max, min) + "\n email code:" + email_code(max, min));
//            } catch (InterruptedException ex) {
//                Logger.getLogger(Random_n.class.getName()).log(Level.SEVERE, null, ex);
//            }
//        }
        return user_code(max, min);
    }

    int user_code(Double max, Double min) {
        Double n2 = Math.random();
        Double new_number = (n2 * ((max - min) + 1)) + min;
        int rounded = (int) Math.round(new_number);
        if (rounded > max) {
            rounded -= 1;
        }
        return rounded;
    }

    String email_code(Double max, Double min) {

        String str1 = Integer.toHexString(user_code(max, min));
        String str2 = Integer.toHexString(user_code(max - 1, min));
        String str3 = Integer.toHexString(user_code(max - 2, min));

        Random r = new Random();
        int n = r.nextInt() * 10;
        String joint1 = Integer.toHexString(n);
        return str1 + "." + joint1 + "." + str2 + "c" + str3;
    }

    
}
