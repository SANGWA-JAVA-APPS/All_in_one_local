/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cg.dal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author SANGWA
 */
public class Queries {

    public static ArrayList<Object>  account_types() {
       ArrayList<Object> some_qt = new ArrayList<>();
        some_qt.add(" select * from account_type order by account_type.account_type_id desc");
        some_qt.add(title);
        return some_qt;
    }

    private static final String title[] = new String[]{"ACCOUNT TYPE ID", "NAME"};

    public static ArrayList<Object> account_types(int rows) {
        ArrayList<Object> some_qt = new ArrayList<>();
        some_qt.add(" select * from account_type order by account_type.account_type_id desc limit " + rows);
        some_qt.add(title);
        return some_qt;
    }

    public static ArrayList<Object> query_title() {
        ArrayList<Object> some_qt = new ArrayList<>();
        some_qt.add(" select * from account_type order by account_type.account_type_id desc");
        some_qt.add(title);
        return some_qt;
    }

}
