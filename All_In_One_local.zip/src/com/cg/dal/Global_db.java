/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cg.dal;

 

/**
 *
 * @author SANGWA
 */
public class Global_db {
    //databse
    public static String app_folder_name = "cofee_shop";
    public static String app_name = "cofee_shop";
    public static String db_name = "cofee_shop.db";
    public static String user_path=System.getProperty("user.home");
        public static String db_path = "jdbc:sqlite:" + user_path + "/" + app_folder_name + "/data/" + db_name;
    public static String user_username = "username";
    public static String user_password = "password";
    public static String user_cat_name = "name";

    public static String app_default_psw = "123123";

    //---End database
    //-
}
