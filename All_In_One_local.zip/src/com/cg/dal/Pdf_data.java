/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cg.dal;

import com.cg.model.Account_type;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author SANGWA
 */
public class Pdf_data {

      Db_con con = new Db_con();

    public ArrayList account_type() throws SQLException {
        ArrayList account_types = new ArrayList();

        try {

            PreparedStatement pst = con.conection().prepareStatement(Queries.account_types().get(0).toString());
            ResultSet res = pst.executeQuery();
            int i = 0;
            while (res.next()) {
                 
                account_types.add( new Account_type(res.getInt("account_type_id"), res.getString("name")));
                                
                i++;
            }

        } catch (SQLException e) {
            System.out.println(e.toString());
            e.printStackTrace();
        } finally {
            if (con != null) {
                con.conection().close();
            }
        }
        System.out.println(account_types);
        return account_types;
    }
    
    
    
}
