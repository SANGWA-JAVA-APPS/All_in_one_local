/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cg.dal;

import alli_in_one_local.Global;
import com.cg.dal.Inserts;
import com.cg.dal.Uni_records;
import java.io.File;
import java.io.IOException;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Logger;

import javax.swing.JOptionPane;

public class Db_con {

    public boolean DbConnection() {

        try {
            String url = "jdbc:mysql://localhost:3306/hospital";
            String user = "sangwa";
            String passwd = "A.manigu125";
            java.sql.Connection conn = DriverManager.getConnection(url, user, passwd);
            return true;

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error with db, please remember to add Mysql JDBC Driver library,thx ");
            return false;

        }
    }

    //Create db
    public void create_environment() {
        try {
            new File(Global_db.user_path + "/" + Global_db.app_folder_name).mkdir();
            new File(Global_db.user_path + "/" + Global_db.app_folder_name + "/data").mkdir();
            new File(Global_db.user_path + "/" + Global_db.app_folder_name + "/data/" + Global_db.db_name).createNewFile();//Create db file

            create_user("username", "password", "category");
            create_user_category("name");
            create_account_type("name");
            
            create_prod_category();
            create_product();
            create_prod_stock_level();
            create_prod_purchase();
            create_prod_sale();
            create_menu_items();
            create_menu_items_sale();
            // default data
            String user_cats[] = {"admin", "user"};
            for (String cat : user_cats) {
                new Inserts().new_user_category(cat);
                new Inserts().new_user(cat, Global_db.app_default_psw, new Uni_records().get_last_user_category());
                new Inserts().new_account_type(cat);
            
            }
               //Create settings table
            create_app_settings();
            System.out.println("Environment created, ...");

        } catch (IOException e) {
            System.out.println("Error creating the environment, ..");
        }
    }
    //Create tables
    //Insert default data
    Global_db ctrl = new Global_db();

    public void create_user(String username, String password, String cat) {
        create_table("user",
                username + " VARCHAR(60)," + password + " VARCHAR(60), "
                + cat + " integer",
                " ,FOREIGN KEY (" + cat + ") REFERENCES user_category (user_category_id) \n"
                + " ON DELETE CASCADE ON UPDATE NO ACTION");
    }

    public void create_user_category(String name) {
        create_table("user_category",
                name + " VARCHAR(60)",
                "");
    }

    
    //<editor-fold defaultstate="collapsed" desc="----------Stock ------------">
    public void create_prod_category(){
        create_table("prod_category", 
                "name VARCHAR(50)", "");
    }
    public void create_product(){
        create_table("product", 
                "name VARCHAR(50),  category integer ",
                 " ,FOREIGN KEY (category) REFERENCES prod_category (prod_category_id) \n"
                + " ON DELETE CASCADE ON UPDATE NO ACTION");
    }
    
    public void create_prod_stock_level(){
        create_table("prod_stock_level",
                "product integer, quantity_remaining integer,"
                        + " prev_quantity integer,entry_date VARCHAR(50), user integer",
        " ,FOREIGN KEY (product) REFERENCES product (product_id) \n"
                + " ON DELETE CASCADE ON UPDATE NO ACTION");
    }
    public void create_prod_purchase(){
        create_table("prod_purchase",
                "product integer, purchased_quantity integer,"
                        + " unit_cost integer,"
                        + " entry_date VARCHAR(50),"
                        + " user integer",
        " ,FOREIGN KEY (product) REFERENCES product (product_id) \n"
                + " ON DELETE CASCADE ON UPDATE NO ACTION");
    }
    public void create_prod_sale(){
        create_table("prod_sale",
                "product integer, sold_quantity integer,"
                        + " unit_cost integer,"
                        + " entry_date VARCHAR(50),"
                        + " user integer",
        " ,FOREIGN KEY (product) REFERENCES product (product_id) \n"
                + " ON DELETE CASCADE ON UPDATE NO ACTION");
    }
    public void create_menu_items(){
        create_table("menu_items",
                "name VARCHAR(50), price integer"  ,  "  ");
    }
    public void create_menu_items_sale(){
        create_table("menu_items_sale",
                "date VARCHAR(50), number_items integer,"
                        + " price_each integer, user integer,"
                        + " menu_item integer"  , 
                 " ,FOREIGN KEY (menu_item) REFERENCES menu_item (menu_item_id) \n"
                + " ON DELETE CASCADE ON UPDATE NO ACTION");
    }
//</editor-fold>
    
    
    
    public void create_account_type(String name) {
            create_table("account_type", name + "  VARCHAR(50)", "");
    }

    public void create_app_settings() {
        create_table("app_settings", "bus_name VARCHAR (60), owner_name VRCHAR(60), last_usage VARCHAR(60), app_status VARCHAR(60), phone VARCHAR(60)", "");

    }

    public void create_table(String table_name, String fields, String relationships) {
        //<editor-fold defaultstate="collapsed" desc=" --- create table-----">
        java.sql.Connection conn = null;
        Statement stmt = null;
        String JDBC_DRIVER = "org.sqlite.JDBC";
        try {
            // STEP 1: Register JDBC driver 
            Class.forName(JDBC_DRIVER);
            //STEP 2: Open a connection 
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(ctrl.db_path);
            //STEP 3: Execute a query 
            System.out.println("Creating table in given database...");
            stmt = conn.createStatement();
            String sql = "CREATE TABLE  IF NOT EXISTS " + table_name
                    + "(" + table_name + "_id INTEGER not NULL PRIMARY KEY AUTOINCREMENT , "
                    + fields //These are the other fields
                    + "" + relationships
                    + ")";
            stmt.executeUpdate(sql);
            System.out.println("Created table in given database...");

            // STEP 4: Clean-up environment 
        } catch (SQLException se) {
            //Handle errors for JDBC 
            se.printStackTrace();
        } catch (ClassNotFoundException e) {
            //Handle errors for Class.forName 
            e.printStackTrace();
        } finally {
//            new Db_con().close_db(conn, stmt);
        } //end try 
        System.out.println("Goodbye!");
//</editor-fold>
    }

    public java.sql.Connection conection() {
        java.sql.Connection conn = null;

        Statement stmt = null;
        try {

            // db parameters
            String url = "jdbc:sqlite:" + Global_db.user_path + "/" + Global_db.app_name + "/data/" + Global_db.db_name;
            // create a connection to the database
            conn = DriverManager.getConnection(url);
//            System.out.println("Connection to SQLite has been established.");

        } catch (SQLException e) {
            System.out.println(e.getMessage());

        }
        return conn;
    }

    public boolean db_exists(String path) {
        File fb = new File(path);
        return fb.exists();

    }

    public boolean get_if_table_exists(String table_name) {
        ResultSet rs = null;
        int rows = 0;
        try {
            DatabaseMetaData md = this.conection().getMetaData();
            rs = md.getTables(null, null, table_name, null);
            rs.last();
            rows = rs.getRow();
        } catch (SQLException ex) {
            Logger.getLogger(ex.toString());
        }
        return rows > 0;
    }

    public void close_db_res(java.sql.Connection connection, ResultSet res, Statement statement) {

        // Step 3: Closing database connection
        try {
            if (null != connection) {
                // cleanup resources, once after processing
                res.close();
                statement.close();
                // and then finally close connection
                connection.close();
            }
        } catch (SQLException sqlex) {
            sqlex.printStackTrace();
        }
    }

    public void close_db(java.sql.Connection connection, Statement statement) {

        // Step 3: Closing database connection
        try {
            if (null != connection) {
                // cleanup resources, once after processing

                statement.close();
                // and then finally close connection
                connection.close();
            }
        } catch (SQLException sqlex) {
            sqlex.printStackTrace();
        }
    }

    public void close_db(java.sql.Connection connection, PreparedStatement statement) {

        // Step 3: Closing database connection
        try {
            if (null != connection) {
                // cleanup resources, once after processing
                // and then finally close connection
                connection.close();
            }if (null!= statement) {
                 statement.close();
            }
        } catch (SQLException sqlex) {
            sqlex.printStackTrace();
        }
    }

}
