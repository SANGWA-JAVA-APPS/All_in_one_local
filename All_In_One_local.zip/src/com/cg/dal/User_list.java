/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cg.dal;

import alli_in_one_local.Global;
import java.awt.FlowLayout;
import java.sql.SQLException;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

/**
 *
 * @author SANGWA
 */
public class User_list extends JFrame {

    Multi_records data_list = new Multi_records();
    Box bx = Box.createVerticalBox();
    JTable tb= new JTable();

    FlowLayout search_layout= new FlowLayout(FlowLayout.LEFT, 5, 5);
    String search_title="";
    
    public User_list() throws SQLException {
        new Global().List_init(this, "Users List", 900, 500);
        data_list.load_account(tb);
        JPanel search_pane= new Global().search_layout("search User",search_layout);
        bx.add(search_pane);
        bx.add(new JScrollPane(tb));
        add(bx);
    }

   
}
