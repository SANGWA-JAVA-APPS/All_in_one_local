package com.cg.dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * By SANGWA At CODEGURU LTD. sangwa22@gmail.com using hp
 */
public class Inserts {

    Connection conn = null;

    public void new_user(String username, String password, int cat) {
        PreparedStatement state = null;
        conn = new com.cg.dal.Db_con().conection();
        try {
            String insert = "insert into user (username,password,category) values(?,?,?)";
            state = new Db_con().conection().prepareStatement(insert);
            state.setString(1, username);
            state.setString(2, password);
            state.setInt(3, cat);
            state.execute();
        } catch (SQLException e) {
            System.out.println("Error inserting user: " + e.toString());
        } finally {
//            conn.close_db(conn.conection(), state);
        }
    }

    public void new_user_category(String name) {
        PreparedStatement state = null;
        conn = new Db_con().conection();
        try {
            String insert = "insert into user_category (name) values(?)";
            state = new Db_con().conection().prepareStatement(insert);
            state.setString(1, name);
            state.execute();
        } catch (SQLException e) {
            System.out.println("Error inserting user category : " + e.toString());
        } finally {
//            conn.close_db(conn.conection(), state);
        }
    }
    public void new_account_type(String name) {
        PreparedStatement state = null;
        conn = new Db_con().conection();
        System.out.println("Are we inserting?");
        try {
            String insert = "insert into account_type (name) values(?)";
            state = conn.prepareStatement(insert);
            state.setString(1, name);
            state.execute();
        } catch (SQLException e) {
            System.out.println("Error inserting user category : " + e.toString());
        } finally {
//            conn.close_db(conn.conection(), state);
        }
    }

    public void new_app_settings(String business_name, String client_name, String last_timeusage, String status, String phone) {
        PreparedStatement state = null;
        conn = new Db_con().conection();
        try {
            String insert = "insert into app_settings (bus_name,owner_name,last_usage,app_status,phone) values(?,?,?,?,?)";
            state = new Db_con().conection().prepareStatement(insert);
            state.setString(1, business_name);
            state.setString(2, client_name);
            state.setString(3, last_timeusage);
            state.setString(4, status);
            state.setString(5, phone);
            state.execute();
        } catch (SQLException e) {
            System.out.println("Error inserting user App settings : " + e.toString());
        } finally {
//            conn.close_db(conn.conection(), state);
        }
    }

}
