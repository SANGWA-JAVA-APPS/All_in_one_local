/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cg.dal;

import java.awt.Dimension;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JTable;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author SANGWA
 */
public class Multi_records {

    Db_con con = new Db_con();

    public void  account_type(JTable tb, String query)throws SQLException{
         PreparedStatement pst=null;
        try {
            PreparedStatement t_pst = con.conection().prepareStatement(query);
            ResultSet res1 = t_pst.executeQuery();
            int t = 0;
            while (res1.next()) {
                t += 1;
            }
              pst = con.conection().prepareStatement(query);
            String title[] = (String[]) Queries.query_title().get(1);

            Object[][] data = new Object[t][5];
            ResultSet res = pst.executeQuery();
            int i = 0;
            while (res.next()) {
                data[i][0] = res.getInt("account_type_id");
                data[i][1] = res.getString("name");
                i++;
            }
            DefaultTableModel dt = new DefaultTableModel(data,title );
           
            tb.setModel(dt);
 

        } catch (SQLException e) {
            System.out.println(e.toString());
            e.printStackTrace();
        } finally {
//            if (con != null) {
//                con.close_db(con.conection(), pst);
//            }
        }
    }
    public void load_account(JTable tb) throws SQLException {
        account_type(tb, Queries.account_types().get(0).toString());
    }
    public void load_account(JTable tb,int rows) throws SQLException {
        account_type(tb, Queries.account_types(rows).get(0).toString());
    }

}
