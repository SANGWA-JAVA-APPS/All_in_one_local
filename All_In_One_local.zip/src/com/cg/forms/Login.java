/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cg.forms;

import alli_in_one_local.Global;
import alli_in_one_local.Homepage;
import com.cg.dal.Db_con;
import com.cg.dal.Global_db;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;

/**
 *
 * @author SANGWA
 */
public class Login extends JFrame {

    Box bx = Box.createVerticalBox();
    JButton btn_login = new JButton("Login");
    JButton btn_cancel = new JButton("Cencel");
    JButton btn_view = new JButton("Login");
    JTextField txt_username = new JTextField(30);
    JTextField txt_password = new JTextField(30);

    public Login() {
        if (!new Db_con().db_exists(Global_db.user_path + "/" + Global_db.app_folder_name + "/data/" + Global_db.db_name)) {
            new Db_con().create_environment();
        } else {
            System.out.println("Db exists");
        }

        setSize(600, 300);
        setCenter();

        JPanel status = new JPanel();
        JPanel body = new JPanel();JLabel lbl= new JLabel();

        new Global().setup_stauts_layout(status,lbl, "USER REGISTRATION FORM");

        bx.add(status);
        FlowLayout login_layout = new FlowLayout(FlowLayout.CENTER, 4, 4);
        JPanel uname_pane = new JPanel();
        uname_pane.setLayout(login_layout);

        JPanel psw_pane = new JPanel();
        psw_pane.setLayout(login_layout);
        uname_pane.add(new Global().input_layout("Username: ", txt_username));
        psw_pane.add(new Global().input_layout("Password: ", txt_password));
        body.setForeground(Color.white);
        bx.add(uname_pane);
        bx.add(psw_pane);
        setup_buttons_layout(body, btn_login, btn_cancel, btn_view, this);

        bx.add(body);
        add(bx);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void setCenter() throws SecurityException, HeadlessException {
        Dimension objDimension = Toolkit.getDefaultToolkit().getScreenSize();
        int iCoordX = (objDimension.width - this.getWidth()) / 2;
        int iCoordY = 150;
        this.setLocation(iCoordX, iCoordY);
//        this.setAlwaysOnTop(true);
    }

    public void setup_buttons_layout(JPanel pane, JButton login, JButton cancel, JButton view, JFrame frm) {
        Color clr = new Color(20, 200, 200);
        int padding = 3;
        Border bevelLoweredBorder = BorderFactory.createLineBorder(Color.green, 3);
        Font current = new Font("Century gothic", Font.PLAIN, 12);
        cancel.setBackground(Color.red);
        cancel.setMargin(new Insets(padding, padding, padding, padding));
        cancel.setForeground(Color.white);
        cancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frm.setVisible(false);
                System.exit(0);
            }
        });
        view.setMargin(new Insets(padding, padding, padding, padding));
        login.setMargin(new Insets(padding, padding, padding, padding));
        login.setMargin(new Insets(4, 4, 4, 4));
        cancel.setMargin(new Insets(4, 4, 4, 4));
        login.setFont(current);
        login.setBackground(clr);
        login.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (!"".equals(txt_username.getText()) && !"".equals(txt_password.getText())) {
                    //Login Process
                    new Homepage().setVisible(true);
                    frm.setVisible(false);
                } else {
                    JOptionPane.showMessageDialog(null, "You have to enter all the fields");
                }

            }
        });
//        pane.add(view);
        pane.setBackground(Color.white);
        pane.add(cancel);

        pane.add(login);
        pane.setLayout(new FlowLayout(FlowLayout.RIGHT, 10, 30));
    }

    public static void main(String[] args) {
        new Login();
    }
}
