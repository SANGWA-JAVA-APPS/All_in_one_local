/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cg.model;

/**
 *
 * @author SANGWA
 */
public class Account_type {

    private int account_type_id;
    private String name ;

    public Account_type() {
    }
    
    
    public Account_type(int account_type_id, String name) {
        this.account_type_id = account_type_id;
        this.name = name;
    }

    public int getAccount_type_id() {
        return account_type_id;
    }

    public void setAccount_type_id(int account_type_id) {
        this.account_type_id = account_type_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

   
    
}
