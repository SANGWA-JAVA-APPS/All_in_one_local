/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cg.model;

import java.util.ArrayList;
import java.util.Map;

/**
 *
 * @author hp
 */
public class PeopleList {

    public ArrayList getDataBeanList() {
        ArrayList dataBeanList = new ArrayList();
        dataBeanList.add(produceData("SANGWA", "North Delhi", "Delhi", "India"));
        dataBeanList.add(produceData("Dennis Ritchie", "Sacramento", "California", "USA"));
        dataBeanList.add(produceData("V.Anand", "Chennai", "Tamil Nadu", "India"));
        dataBeanList.add(produceData("Parvez", "Upton Park", "London", "UK"));
        return dataBeanList;
    }

    

    private PeopleBean produceData(String name, String city, String state, String country) {
        PeopleBean dataBean = new PeopleBean();
        dataBean.setName(name);
        dataBean.setCity(city);
        dataBean.setState(state);
        dataBean.setCountry(country);
        return dataBean;
    }

}
