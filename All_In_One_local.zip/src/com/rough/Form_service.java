/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rough;

import com.sun.glass.ui.Cursor;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 *
 * @author SANGWA
 */
public class Form_service extends JFrame {
 
    public Form_service(){
         setVisible(true);
         setSize(500,300);
         JLabel lbl=new JLabel("hello");
         add(lbl);
         this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         
         
         while (true) {
             try {
                 Thread.sleep(3000);
                 System.out.println("Going, ..");
                 lbl.setText("in form");
             } catch (InterruptedException ex) {
                 Logger.getLogger(Form_service.class.getName()).log(Level.SEVERE, null, ex);
             }
            
        }
    }
    
    
    public static void main(String[] args) {
       new Form_service();
    }
}
