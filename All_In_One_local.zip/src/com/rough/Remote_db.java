/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rough;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author SANGWA
 */
public class Remote_db {

    Conn con=new Conn();
    public Remote_db() {
        int i = 0;
        while (true) {
            PreparedStatement pst = null;
            
            try {
                Thread.sleep(2000);
            } catch (InterruptedException ex) {
                Logger.getLogger(Remote_db.class.getName()).log(Level.SEVERE, null, ex);
            }

            try {
                String str = "insert into user(name) values(?)";
                pst = con.con().prepareStatement(str);
                pst.setString(1, "Ngassa " + i);
                pst.executeUpdate();
                pst.close();

            } catch (SQLException ex) {
                Logger.getLogger(Remote_db.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                if (con.con() != null) {
                    try {
                        con.con().close();
                    } catch (SQLException ex) {
                        Logger.getLogger(Remote_db.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                if (pst != null) {
                    try {
                        pst.close();
                    } catch (SQLException ex) {
                        Logger.getLogger(Remote_db.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
            i += 1;
        }
    }

    public static void main(String[] args) {
        new Remote_db();
    }

    class Conn {

        public java.sql.Connection con() {
            
            
            
            java.sql.Connection conn = null;
            try {
                 Class.forName("com.mysql.jdbc.Driver");
//                String url = "jdbc:mysql://192.168.10.4:3306/incomefinal";
                String url = "jdbc:mysql://192.168.10.4/incomefinal";
                String user = "hugues";
                String passwd = "12345";
                conn = DriverManager.getConnection(url, user, passwd);
            } catch (SQLException e) {
                System.out.println(e.toString());
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Remote_db.class.getName()).log(Level.SEVERE, null, ex);
            }
            return conn;
        }
    }
}
