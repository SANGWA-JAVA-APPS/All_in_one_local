/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rough;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author SANGWA
 */
public class Open_jar {

    public static void main(String[] args) {
        try {
            File f = new File( "C:\\Program Files (x86)\\Coffe\\Alli_in_one_local.exe");
            f.getAbsoluteFile();
            JOptionPane.showMessageDialog(null, "The parent diretory: "
                    + System.getProperty("user.dir"));
            
            
            System.out.println("parent folder: "+ f.getParent()+" the fire name: "+ f.getName());
            
            if (f.exists()) {
                Desktop d = Desktop.getDesktop();
                d.open(f);
            } else {
                System.out.println("File not found!!");
            }

        } catch (IOException ex) {
            Logger.getLogger(Open_jar.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
