/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rough;

import static com.sun.javafx.tk.Toolkit.getToolkit;
import java.awt.Desktop;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JApplet;
import javax.swing.JFrame;

/**
 *
 * @author SANGWA
 */
public class Test_rough extends JApplet {

    Image image;

    @Override
    public void paint(Graphics g) {
        g.drawImage(image, 20, 20, this);
    }

    @Override
    public void init() {
            URL url = getClass().getResource("Skycrapper.png");
//            URL url = getClass().getResource(System.getProperty("user.home") + "\\Desktop\\delete\\Skycrapper.png");
            image = getToolkit().getImage(url);
         
    }

    public static void main(String[] args) {
        JFrame form = new JFrame("This is the form");
        form.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Test_rough t = new Test_rough();

        form.getContentPane().add(t);
        t.init();
        form.setSize(600, 400);
        form.setVisible(true);
        t.start();
    }
}
