/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rough;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author SANGWA
 */
public class Create_file_remotely {

    public Create_file_remotely() {

        String ip = "";
        int n_files = 0;
        Scanner input = new Scanner(System.in);
//        System.out.println("Enter the ip to create 5 files: ");
//        ip = input.nextLine();

        System.out.println("Enter number of files: ");
        n_files = input.nextInt();
        
        for (int i = 0; i < n_files; i++) {
            try {
                
                File f = new File("\\\\Sangwa-pc\\c\\Users\\SANGWA\\Desktop\\Remote\\sam" + i + ".txt");
                f.createNewFile();
                //  f.delete();

            } catch (IOException ex) {
                Logger.getLogger(Create_file_remotely.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public static void main(String[] args) {
        new Create_file_remotely();
    }

}
